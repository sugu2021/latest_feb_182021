import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Title ,Meta} from '@angular/platform-browser'; 
import { NgForm } from '@angular/forms'
import { Router } from '@angular/router';
 
@Component({
  selector: 'app-videoproduction',
  templateUrl: './videoproduction.component.html',
  styleUrls: ['./videoproduction.component.css']
})
export class VideoproductionComponent implements OnInit {
  arr: any[]=[];
  constructor(meta:Meta, title:Title,private httpClient: HttpClient,private router: Router) {
    title.setTitle('Brandstory Solutions Private Limited Contact Us Location Information');

    meta.addTags([
      {
        name: 'description',
        content: 'Brandstory Solutions Private Limited: No 5, 1st Cross, 3rd Floor Krishna Reddy Colony, Domlur Layout, Bangalore, Karnataka – 560071. Mobile: +91 9811599577 Email: info@brandstory.in. Digital Marketing Company in Bangalore Contact Us Location.'
        }, 
      {
        name: 'keywords',
        content: 'Digital Marketing Company in Bangalore, Digital Marketing Agency in Bangalore, SEO Company in Bangalore, SEO Agency in Bangalore, Online Marketing Company in Bangalore, Internet Marketing Company in Bangalore, UI UX Design Company in Bangalore, Web Design Company in Bangalore'
      },
      {
        name: 'og:type',
        content: 'article'
      },
      {
        name: 'og:title',
        content: 'Brandstory Solutions Private Limited Contact Us Location Information'
      },
      {
        name: 'og:description',
        content: 'Brandstory Solutions Private Limited: No 5, 1st Cross, 3rd Floor Krishna Reddy Colony, Domlur Layout, Bangalore, Karnataka – 560071. Mobile: +91 9811599577 Email: info@brandstory.in. Digital Marketing Company in Bangalore Contact Us Location.'
      },
      {
        name: 'og:url',
        content: 'https://brandstory.in/contact-us/'
      },
      {
        name: 'og:site_name',
        content: 'Digital Marketing Agency | Digital Marketing Company Bangalore | SEO Company'
      },
      {
        name: 'twitter:card',
        content: 'summary_large_image'
      },
      {
        name: 'twitter:description',
        content: 'Brandstory Solutions Private Limited: No 5, 1st Cross, 3rd Floor Krishna Reddy Colony, Domlur Layout, Bangalore, Karnataka – 560071. Mobile: +91 9811599577 Email: info@brandstory.in. Digital Marketing Company in Bangalore Contact Us Location.'
      },
      {
        name: 'twitter:title',
        content:'Brandstory Solutions Private Limited Contact Us Location Information'
      }
    ]);    
  }

  ngOnInit() {
  }

   

   onSubmit(form:NgForm ) {
    this.arr = form.value;
    console.log(JSON.stringify( this.arr));
    console.log(JSON.stringify( form.value));
    console.log(JSON.stringify( form.value.fName));
 
    const formName = form.value.fName;
    const formEmail = form.value.fEmail;
    const formPhone = form.value.fPhone;
    const formService = form.value.fService;
    const formMessage = form.value.fMessage;
    
    let head = new HttpHeaders();
    head.append('Access-Control-Allow-Headers', 'Content-Type');
    head.append('Access-Control-Allow-Methods', 'GET');
    head.append('Access-Control-Allow-Origin', '*');
    this.httpClient.post('https://brandstory.in/assets/thank-you1.php',
    {      
      name:formName,
      email: formEmail,
      phone: formPhone,
      service: formService,
      message: formMessage,
      page:"brandstory.in/contact-us"

    })
    .subscribe(
      (data:any) => {
        // this.router.navigate(['thank-you']);
       window.location.href = "https://brandstory.in/thank-you"
        console.log(data);
      }
    )
    
   }
}
